GoSwap Homepage Pack — Clean landing + CTAs

Adds:
- app/page.tsx      → Clean landing with hero, two CTAs (Lease / Swap), quick info cards, and a simple footer with social links.
- app/swap/page.tsx → Placeholder page until the swap flow is wired.

Notes:
- No external UI libraries; inline styles keep it portable.
- Homepage avoids listing vehicles to keep it clean. Primary paths: /lease and /swap.
