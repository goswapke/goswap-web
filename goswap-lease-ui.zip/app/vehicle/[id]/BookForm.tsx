"use client";
import { useState } from "react";

function toIsoLocal(d: string) {
  // datetime-local returns 'YYYY-MM-DDTHH:mm', make it ISO with Z
  try {
    return new Date(d).toISOString();
  } catch { return d; }
}

export default function BookForm({ vehicleId, prices }: { vehicleId: string, prices: { self: number, chauffeured: number } }) {
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState("");

  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setMsg("");
    setLoading(true);
    const fd = new FormData(e.currentTarget);
    const name = String(fd.get("name")||"");
    const email = String(fd.get("email")||"");
    const phone = String(fd.get("phone")||"");
    const startDate = String(fd.get("startDate")||"");
    const endDate = String(fd.get("endDate")||"");
    const arrivalAtLocal = String(fd.get("arrivalAt")||"");
    const driveMode = String(fd.get("driveMode")||"SELF_DRIVE");

    // Simple arrival time guard 06:00-22:00
    const hour = Number(arrivalAtLocal.slice(11,13));
    if (Number.isFinite(hour) && (hour < 6 || hour > 22)) {
      setMsg("Arrival time must be between 06:00 and 22:00.");
      setLoading(false);
      return;
    }

    const res = await fetch("/api/booking/checkout", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        vehicleId,
        renter: { name, email, phone },
        startDate,
        endDate,
        arrivalAt: toIsoLocal(arrivalAtLocal),
        driveMode,
        prices
      })
    });

    const data = await res.json();
    setLoading(false);
    if (!res.ok) {
      setMsg(data?.error ? JSON.stringify(data.error) : "Failed to create checkout.");
      return;
    }
    if (data.redirect_url) {
      window.location.href = data.redirect_url;
    } else {
      setMsg("No redirect URL returned.");
    }
  }

  return (
    <form onSubmit={submit} style={{border:"1px solid #e5e7eb", borderRadius:8, padding:16}}>
      <h3>Book this vehicle</h3>
      <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:12}}>
        <label>Full name<input required name="name" placeholder="Your name" /></label>
        <label>Email<input required type="email" name="email" placeholder="you@example.com" /></label>
        <label>Phone<input name="phone" placeholder="0700..." /></label>
        <label>Start date<input required type="date" name="startDate" /></label>
        <label>End date<input required type="date" name="endDate" /></label>
        <label>Arrival time<input required type="datetime-local" name="arrivalAt" /></label>
        <label>Drive mode
          <select name="driveMode" defaultValue="SELF_DRIVE">
            <option value="SELF_DRIVE">Self-drive</option>
            <option value="CHAUFFEURED">Chauffeured</option>
          </select>
        </label>
      </div>
      <button type="submit" disabled={loading} style={{marginTop:12, padding:"8px 12px"}}>{loading ? "Processing..." : "Proceed to Pay"}</button>
      {msg && <p style={{color:"crimson", marginTop:8}}>{msg}</p>}
    </form>
  );
}
