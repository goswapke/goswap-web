import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

const db: any = prisma;

export async function POST(req: Request) {
  try {
    const { orderTrackingId, merchantReference } = await req.json();
    const base = process.env.PESAPAL_BASE_URL;
    const key = process.env.PESAPAL_CONSUMER_KEY;
    const secret = process.env.PESAPAL_CONSUMER_SECRET;

    if (!base || !key || !secret) {
      return NextResponse.json({ ok: false, error: "Env missing" }, { status: 500 });
    }

    // token
    const tr = await fetch(`${base}/api/Auth/RequestToken`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ consumer_key: key, consumer_secret: secret }),
    });
    const tdata = await tr.json();
    const token = tdata.token || tdata.access_token;
    if (!token) return NextResponse.json({ ok: false, error: "No token" }, { status: 500 });

    // status
    const url = orderTrackingId
      ? `${base}/api/Transactions/GetTransactionStatus?orderTrackingId=${encodeURIComponent(orderTrackingId)}`
      : `${base}/api/Transactions/GetTransactionStatus?merchantReference=${encodeURIComponent(merchantReference || "")}`;

    const sr = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
    const s = await sr.json();

    const statusStr = String(s.payment_status || s.status || "").toUpperCase();
    const paid = statusStr.includes("PAID") || statusStr.includes("COMPLETED") || statusStr.includes("SUCCESS");

    // Update DB if we can match the payment
    const payment = await db.payment.findFirst({
      where: {
        OR: [
          { pesapalTrackingId: orderTrackingId || "" },
          { pesapalMerchantRef: merchantReference || "" },
        ],
      },
    });

    if (payment) {
      await db.payment.update({
        where: { id: payment.id },
        data: { status: paid ? "PAID" : "FAILED" },
      });
      if (payment.bookingId && paid) {
        await db.booking.update({ where: { id: payment.bookingId }, data: { paymentStatus: "PAID" } });
      }
    }

    return NextResponse.json({ ok: paid, raw: s, matchedPaymentId: payment?.id || null });
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: String(e) }, { status: 500 });
  }
}
