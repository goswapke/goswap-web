Minimal Lease UI — Drop-in pages

Adds:
- app/lease/page.tsx                  → Vehicle list with city filter (NAIROBI/MOMBASA/KISUMU)
- app/vehicle/[id]/page.tsx           → Vehicle details page
- app/vehicle/[id]/BookForm.tsx       → Client form that calls /api/booking/checkout and redirects to Pesapal

Notes:
- Uses prisma via '@/lib/db' and casts to 'any' to avoid transient type errors during build.
- Expects Vehicle fields: id, title, city, selfDrivePricePerDay, chauffeuredPricePerDay.
- Arrival time guard: only allows 06:00–22:00 (client-side); backend can enforce later if needed.

How to use:
1) Extract the zip at your project root (it will create/overwrite files in app/).
2) Ensure your DB has at least one Vehicle row (see the seed example we shared).
3) Visit /lease, click a vehicle, fill form, and it will hit /api/booking/checkout then redirect to Pesapal.
