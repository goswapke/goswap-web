import { NextResponse } from "next/server";
import { randomUUID } from "crypto";
import { prisma } from "@/lib/db";

const db: any = prisma; // keep relaxed typing for now

export async function POST(req: Request) {
  try {
    const base = process.env.PESAPAL_BASE_URL;
    const key = process.env.PESAPAL_CONSUMER_KEY;
    const secret = process.env.PESAPAL_CONSUMER_SECRET;
    const callback = process.env.PESAPAL_CALLBACK_URL || "http://localhost:3000/success";
    if (!base || !key || !secret) {
      return NextResponse.json({ error: "Pesapal env missing" }, { status: 500 });
    }

    // expected JSON: { amount, currency?, description?, bookingId?, kind? }
    const {
      amount,
      currency = "KES",
      description = "GoSwap Payment",
      bookingId,
      kind = "LEASE",
      merchantReference,
      buyer = { email: "customer@example.com", first_name: "Go", last_name: "Swap", phone: "0700000000" },
    } = await req.json();

    if (!amount || amount <= 0) {
      return NextResponse.json({ error: "Invalid amount" }, { status: 400 });
    }

    // 1) Prepare a merchant reference and create a Payment row (PENDING)
    const ref = merchantReference || randomUUID();
    const payment = await db.payment.create({
      data: {
        kind,
        status: "PENDING",
        amount: Math.round(Number(amount)),
        currency,
        pesapalMerchantRef: ref,
        bookingId: bookingId || null,
      },
    });

    // 2) Auth token
    const tr = await fetch(`${base}/api/Auth/RequestToken`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ consumer_key: key, consumer_secret: secret }),
    });
    const tdata = await tr.json();
    const token = tdata.token || tdata.access_token;
    if (!token) return NextResponse.json({ error: "No token" }, { status: 500 });

    // 3) Submit order
    const body = {
      id: ref,
      currency,
      amount,
      description,
      callback_url: callback,
      notification_id: "", // (add IPN later)
      billing_address: {
        email_address: buyer.email || "customer@example.com",
        first_name: buyer.first_name || "Go",
        last_name: buyer.last_name || "Swap",
        phone_number: buyer.phone || "0700000000",
        country_code: "KE",
      },
    };

    const pr = await fetch(`${base}/api/Transactions/SubmitOrderRequest`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify(body),
    });
    const pdata = await pr.json();
    if (!pr.ok) {
      return NextResponse.json({ error: pdata }, { status: 500 });
    }

    // Pesapal returns order tracking ID; store it back to Payment
    const tracking = pdata.order_tracking_id || pdata.orderTrackingId || pdata.order_tracking_Id || pdata.tracking_id;
    if (tracking) {
      await db.payment.update({
        where: { id: payment.id },
        data: { pesapalTrackingId: String(tracking) },
      });
    }

    return NextResponse.json({
      redirect_url: pdata.redirect_url || pdata.redirectUrl,
      merchant_reference: ref,
      order_tracking_id: tracking || null,
      payment_id: payment.id,
    });
  } catch (err: any) {
    return NextResponse.json({ error: String(err) }, { status: 500 });
  }
}
