import { prisma } from "@/lib/db";
import Link from "next/link";

const db: any = prisma;

export const dynamic = "force-dynamic";

type Search = { searchParams?: { city?: string } };

const CITIES = ["NAIROBI","MOMBASA","KISUMU"];

async function getVehicles(city?: string) {
  const where: any = {};
  if (city && CITIES.includes(city.toUpperCase())) where.city = city.toUpperCase();
  return db.vehicle.findMany({
    where,
    orderBy: { createdAt: "desc" },
    take: 60,
    select: { id: true, title: true, city: true, selfDrivePricePerDay: true, chauffeuredPricePerDay: true }
  });
}

export default async function LeasePage({ searchParams }: Search) {
  const city = (searchParams?.city || "").toUpperCase();
  const items = await getVehicles(city);

  return (
    <div style={{maxWidth: 980, margin: "30px auto", padding: 16}}>
      <h1>Lease a vehicle</h1>
      <form method="get" style={{margin: "12px 0", display: "flex", gap: 8, alignItems: "center"}}>
        <label htmlFor="city">City:</label>
        <select id="city" name="city" defaultValue={city || ""}>
          <option value="">All</option>
          {CITIES.map(c => (<option key={c} value={c}>{c}</option>))}
        </select>
        <button type="submit">Filter</button>
        <Link href="/lease">Reset</Link>
      </form>

      <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fill, minmax(260px,1fr))", gap: 16}}>
        {items.map((v:any) => (
          <div key={v.id} style={{border:"1px solid #e5e7eb", borderRadius:8, padding:12}}>
            <div style={{fontWeight:600, marginBottom:4}}>{v.title || "Vehicle"}</div>
            <div style={{fontSize:12, opacity:0.8, marginBottom:8}}>City: {v.city}</div>
            <div style={{fontFamily:"monospace", fontSize:14, marginBottom:8}}>
              Self-drive: KES {v.selfDrivePricePerDay} /day<br/>
              Chauffeured: KES {v.chauffeuredPricePerDay} /day
            </div>
            <Link href={`/vehicle/${v.id}`} style={{display:"inline-block", padding:"8px 10px", border:"1px solid #111", borderRadius:6}}>View & Book</Link>
          </div>
        ))}
      </div>

      {items.length === 0 && <p>No vehicles found{city ? ` in ${city}` : ""}.</p>}
    </div>
  );
}
