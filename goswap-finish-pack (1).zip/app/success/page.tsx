"use client";
import { useEffect, useState } from "react";

export default function SuccessPage() {
  const [state, setState] = useState<{ ok?: boolean; msg: string }>({ msg: "Checking payment..." });

  useEffect(() => {
    const url = new URL(window.location.href);
    const orderTrackingId = url.searchParams.get("OrderTrackingId") || url.searchParams.get("orderTrackingId") || "";
    const merchantReference = url.searchParams.get("merchant_reference") || url.searchParams.get("merchantReference") || "";

    fetch("/api/pesapal/status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ orderTrackingId, merchantReference }),
    })
      .then((r) => r.json())
      .then((j) => {
        if (j.ok) setState({ ok: true, msg: "Payment confirmed. Booking secured. 🎉" });
        else setState({ ok: false, msg: "Payment not confirmed yet. If you were charged, please wait a minute then refresh." });
      })
      .catch(() => setState({ ok: false, msg: "Could not verify payment." }));
  }, []);

  return (
    <div style={{ maxWidth: 640, margin: "40px auto", padding: 16 }}>
      <h1>Thank you</h1>
      <p>{state.msg}</p>
      <a href="/" style={{ display: "inline-block", marginTop: 16 }}>Back to Home</a>
    </div>
  );
}
