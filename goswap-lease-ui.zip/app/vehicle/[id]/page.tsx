import { prisma } from "@/lib/db";
import BookForm from "./BookForm";

const db: any = prisma;

export const dynamic = "force-dynamic";

export default async function VehiclePage({ params }: { params: { id: string } }) {
  const v = await db.vehicle.findUnique({
    where: { id: params.id },
    select: { id:true, title:true, city:true, selfDrivePricePerDay:true, chauffeuredPricePerDay:true }
  });

  if (!v) {
    return <div style={{maxWidth:640, margin:"40px auto", padding:16}}><h1>Vehicle not found</h1></div>;
  }

  return (
    <div style={{maxWidth:680, margin:"30px auto", padding:16}}>
      <h1>{v.title}</h1>
      <p style={{opacity:0.8, fontSize:14}}>City: {v.city}</p>
      <div style={{fontFamily:"monospace", margin:"8px 0 16px"}}>
        Self-drive: KES {v.selfDrivePricePerDay} /day • Chauffeured: KES {v.chauffeuredPricePerDay} /day
      </div>
      <BookForm vehicleId={v.id} prices={{ self: v.selfDrivePricePerDay, chauffeured: v.chauffeuredPricePerDay }} />
    </div>
  );
}
