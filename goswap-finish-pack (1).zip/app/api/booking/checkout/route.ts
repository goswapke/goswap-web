import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

const db: any = prisma;

function daysBetween(start: string, end: string) {
  const a = new Date(start), b = new Date(end);
  const ms = b.getTime() - a.getTime();
  return Math.max(1, Math.ceil(ms / (1000 * 60 * 60 * 24)));
}

export async function POST(req: Request) {
  try {
    const {
      vehicleId,
      renter: { name, email, phone } = { name: "", email: "", phone: "" },
      startDate,
      endDate,
      arrivalAt,
      driveMode = "SELF_DRIVE", // or CHAUFFEURED
      prices = { self: 0, chauffeured: 0 },
      description = "GoSwap Lease Payment",
    } = await req.json();

    if (!vehicleId || !email || !name || !startDate || !endDate || !arrivalAt) {
      return NextResponse.json({ error: "Missing fields" }, { status: 400 });
    }

    // Upsert renter user
    let renter = await db.user.findUnique({ where: { email } });
    if (!renter) {
      renter = await db.user.create({ data: { email, name, phone: phone || "", password: "x", role: "TRAVELER" } });
    }

    // Compute total
    const days = daysBetween(startDate, endDate);
    const unit = driveMode === "CHAUFFEURED" ? Number(prices.chauffeured) : Number(prices.self);
    const total = Math.round(days * unit);

    // Create Booking (PENDING)
    const booking = await db.booking.create({
      data: {
        vehicleId,
        renterId: renter.id,
        startDate: new Date(startDate),
        endDate: new Date(endDate),
        arrivalAt: new Date(arrivalAt),
        driveMode,
        totalPrice: total,
        paymentStatus: "PENDING",
      },
    });

    // Call our Pesapal order route to create Payment + get redirect url
    const res = await fetch(`${process.env.NEXTAUTH_URL || "http://localhost:3000"}/api/pesapal/order`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        amount: total,
        currency: "KES",
        description,
        bookingId: booking.id,
        kind: "LEASE",
        buyer: { email, first_name: name.split(" ")[0] || name, last_name: name.split(" ").slice(1).join(" ") || "User", phone: phone || "0700000000" },
      }),
    });

    const data = await res.json();
    if (!res.ok) return NextResponse.json({ error: data }, { status: 500 });

    return NextResponse.json({ ok: true, redirect_url: data.redirect_url, booking_id: booking.id, payment_id: data.payment_id, order_tracking_id: data.order_tracking_id, merchant_reference: data.merchant_reference });
  } catch (e: any) {
    return NextResponse.json({ error: String(e) }, { status: 500 });
  }
}
