export const dynamic = "force-dynamic";

export default function SwapComingSoon() {
  return (
    <div style={{maxWidth:680, margin:"40px auto", padding:16}}>
      <h1>Swap your car</h1>
      <p style={{opacity:0.8}}>
        The swap flow will let you list your vehicle (with plate, logbook, and 5+ photos), keep your contacts private, and pay a small matching fee. When a match is paid, both parties receive each other's contacts.
      </p>
      <p style={{opacity:0.8}}>For now, start by browsing vehicles to lease.</p>
      <a href="/lease" style={{display:"inline-block", marginTop:12, padding:"10px 14px", border:"1px solid #111", borderRadius:8, textDecoration:"none"}}>Browse Lease</a>
    </div>
  );
}
