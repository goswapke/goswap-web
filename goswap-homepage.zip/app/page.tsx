export const dynamic = "force-static";

export default function HomePage() {
  return (
    <div style={{minHeight:"100dvh", display:"flex", flexDirection:"column"}}>
      {/* Header */}
      <header style={{borderBottom:"1px solid #eee"}}>
        <div style={{maxWidth:1100, margin:"0 auto", padding:"14px 16px", display:"flex", alignItems:"center", justifyContent:"space-between"}}>
          <a href="/" style={{fontWeight:800, fontSize:20, letterSpacing:0.3}}>GoSwap</a>
          <nav style={{display:"flex", gap:14}}>
            <a href="/lease" style={{textDecoration:"none"}}>Lease</a>
            <a href="/swap" style={{textDecoration:"none"}}>Swap</a>
          </nav>
        </div>
      </header>

      {/* Hero */}
      <main style={{flex:1}}>
        <section
          style={{
            background: "linear-gradient(135deg,#0ea5e9 0%, #22c55e 100%)",
            color:"#fff"
          }}
        >
          <div style={{maxWidth:1100, margin:"0 auto", padding:"64px 16px"}}>
            <h1 style={{fontSize:44, lineHeight:1.1, margin:"0 0 12px"}}>
              Move smarter. Lease or swap cars with GoSwap.
            </h1>
            <p style={{opacity:0.95, fontSize:18, margin:"0 0 24px", maxWidth:760}}>
              A trusted travel-mobility marketplace for Kenya. Start in Nairobi, Mombasa, or Kisumu, choose self‑drive or chauffeured, and check out securely via Pesapal.
            </p>
            <div style={{display:"flex", gap:12, flexWrap:"wrap"}}>
              <a href="/lease" style={{background:"#111", color:"#fff", padding:"12px 18px", borderRadius:8, textDecoration:"none"}}>Lease a car</a>
              <a href="/swap" style={{background:"rgba(255,255,255,0.15)", color:"#fff", padding:"12px 18px", borderRadius:8, textDecoration:"none", border:"1px solid rgba(255,255,255,0.35)"}}>Swap a car</a>
            </div>
          </div>
        </section>

        {/* Quick info */}
        <section>
          <div style={{maxWidth:1100, margin:"0 auto", padding:"28px 16px"}}>
            <div style={{display:"grid", gridTemplateColumns:"repeat(auto-fit,minmax(220px,1fr))", gap:16}}>
              <div style={{border:"1px solid #eee", borderRadius:10, padding:16}}>
                <div style={{fontWeight:700, marginBottom:6}}>Fast checkout</div>
                <div style={{opacity:0.75, fontSize:14}}>Pay securely with Pesapal; instant booking confirmation and a clean success page.</div>
              </div>
              <div style={{border:"1px solid #eee", borderRadius:10, padding:16}}>
                <div style={{fontWeight:700, marginBottom:6}}>Clear pricing</div>
                <div style={{opacity:0.75, fontSize:14}}>See self‑drive vs chauffeured daily rates before you book. No hidden fees.</div>
              </div>
              <div style={{border:"1px solid #eee", borderRadius:10, padding:16}}>
                <div style={{fontWeight:700, marginBottom:6}}>Verified partners</div>
                <div style={{opacity:0.75, fontSize:14}}>Listings are reviewed. Number plates are required to avoid duplicates.</div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer style={{borderTop:"1px solid #eee"}}>
        <div style={{maxWidth:1100, margin:"0 auto", padding:"18px 16px", display:"flex", alignItems:"center", justifyContent:"space-between", flexWrap:"wrap", gap:12}}>
          <div style={{opacity:0.8}}>© {new Date().getFullYear()} GoSwap</div>
          <div style={{display:"flex", gap:14}}>
            <a href="https://twitter.com" target="_blank" rel="noreferrer" aria-label="X / Twitter" title="Twitter">🕊️</a>
            <a href="https://instagram.com" target="_blank" rel="noreferrer" aria-label="Instagram" title="Instagram">📸</a>
            <a href="https://facebook.com" target="_blank" rel="noreferrer" aria-label="Facebook" title="Facebook">👍</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
